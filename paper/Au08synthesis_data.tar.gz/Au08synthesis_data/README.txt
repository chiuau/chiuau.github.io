This directory contains the data files of the experiments in our paper
"Synthesis of Strategies from Interaction Traces".

In order to accurately measure the performance of the agents, we repeated the
experiment 100 times.  In each trial, we used different partitions of
training/test sets in the cross-validation test, and we used different random
seeds in the agents' random number generators.  The experimental results
reported in the paper are the averages of 100 trials.

Due to large amount of data generated in the experiments, we record the
interaction traces of one trial only.  But we record the statistics of all 100
trials.  The interaction traces are stored in the compressed file "history.tar.gz",
whereas the statistics of all 100 trials are stored in the directory "statistics".

"history.tar.gz" contains a total of 150 files:

${GAME}_f${PARTITION}_s10_train_roster.txt          - the names of the agents in the training set
${GAME}_f${PARTITION}_s10_train_traces_dup.txt      - the interaction traces of all pairs of
                                                      agents in the training set.  The number in
                                                      the parenthesis of an interaction trace
                                                      is the score of the player 1.
${GAME}_f${PARTITION}_s10_train_traces.txt          - the interaction traces of all pairs of
                                                      agents in the training set, after the
                                                      removal of duplicated interaction traces.
${GAME}_f${PARTITION}_s10_train_solution.txt        - the interaction traces returned by the CIT
                                                      algorithm using the interaction traces in 
                                                      ${GAME}_f${PARTITION}_s10_train_traces.txt
${GAME}_f${PARTITION}_s10_train_summary.csv         - the number of interacion traces in the
                                                      above files.
${GAME}_f${PARTITION}_s10_test_roster.txt           - the names of the agents in the test set
${GAME}_f${PARTITION}_s10_test_base_history.txt     - the records of the games between the base
                                                      agents and the agents in the test set.
${GAME}_f${PARTITION}_s10_test_base_statistics.csv  - the statistics of the games between the base
                                                      agents and the agents in the test set.
${GAME}_f${PARTITION}_s10_test_mca_history.txt      - the records of the games between the MCA
                                                      agents and the agents in the test set.
${GAME}_f${PARTITION}_s10_test_mca_statistics.csv   - the statistics of the games between the base
                                                      agents and the agents in the test set.

where ${GAME} is either ipd, icg, or ibs, and
${PARTITION} is an integer between 1 and 5, inclusively, which denotes a partition
in a cross validiation test.

Each row in the statistics file contains the statistics for one particular agent.
The statistics files contain 7 fields:
1. program     - the name of the agent. The MCA agent is denoted by mca_${name of the base agent}.
2. isRandom    - whether the agent is a probabilistic agent (1 = yes, 0 = no)
3. avgscore    - the average score of the agent when it plays against the agents in the test set.
4. repeatNum   - the number of games between the agent and each agent in the test set (always 100)
5. oppNum      - the number of agents in the test set
6. randOppNum  - the number of probabilistic agents in the test set
7. backupUsage - the ratio of games in which the base agents is invoked times oppNum.
                 If the agent is not a MCA agent, backupUsage = -0.99999

The statistics directory contains 4500 files:

${GAME}_f${PARTITION}_s10_train_summary.csv.condor${id}
${GAME}_f${PARTITION}_s10_test_base_statistics.csv.condor${id}
${GAME}_f${PARTITION}_s10_test_mca_statistics.csv.condor${id}

where ${GAME} is either ipd, icg, or ibs,
${PARTITION} is an integer between 1 and 5, inclusively, and
${id} is an integer between 0 and 99, inclusively, which denotes the trial number.

The Perl script "generate_csv.pl" and "CSV.pm" takes the files in the
statistics directory and output the following files.

  ipd_s10_stat.csv icg_s10_stat.csv ibs_s10_stat.csv
  ipd_stat.R icg_stat.R ibs_stat.R

The ${GAME}_s10_stat.csv files contains the data for plotting the graphs using the Excel files,
whereas the ${game}_stat.R files contains the data for the sign tests.



Tsz-Chiu Au
January 9, 2008



